import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;
import java.util.HashSet;

/**
 * The responder class represents a response generator object.
 * It is used to generate an automatic response.
 * 
 * @author     Michael Kolling and David J. Barnes
 * @version    0.1
 */
public class Responder

{
    private Random randomGenerator;
    private ArrayList<String> Responses;
    private HashMap<String,String> responseMap;
    /**
     * Construct a Responder - nothing to do
     */
    public Responder()
    {
       randomGenerator = new Random();
       Responses =new ArrayList<>();
       fillResponses();   
       responseMap = new HashMap<>();
       fillResponseMap();
    }

    /**
     * Generate a response.
     * @return   A string that should be displayed as the response
     */
    public String randomResponse()
    {
        int index = randomGenerator.nextInt(Responses.size());
        return Responses.get(index);
        
    }
    
    public String generateResponse(HashSet<String> words)
    {   
        for (String word : words) {
        String response = responseMap.get(word);
        if(response !=null) {
            return response;
        }
    }
        
    return randomResponse();
    }
    private void fillResponses()
    {
        Responses.add("That sounds weird.");
        Responses.add("Tell me more about it");
        Responses.add("I need more infromation.");
        Responses.add("That's not a bug that's a feature.");
        
    }
    
    private void fillResponseMap()
    {
    responseMap.put("slow","I think it has to do with your hardware");
    responseMap.put("bug", "Well you know, all software has some bugs");
    responseMap.put("expensive","Our cost is quite competitive");
    }
}
